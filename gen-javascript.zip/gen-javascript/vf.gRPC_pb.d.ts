// package: vf.gRPC
// file: vf.gRPC.proto

/* tslint:disable */
/* eslint-disable */

import * as jspb from "google-protobuf";
import * as vf_pb from "./vf_pb";
